The images in this folder are of my work on Warhammer Age Of Sigmar miniatures. 
Have fun looking at them and I hope you enjoy them. 
Please do not use or forward them for any other purpose than to test them in this educational project.

Thank you, project creator Alessandro Diana.